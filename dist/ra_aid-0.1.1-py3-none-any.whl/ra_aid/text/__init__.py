from .processing import truncate_output

__all__ = ['truncate_output']
